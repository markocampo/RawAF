<div id="wrap">
	<div id="filter">
		<a href="view_price.php">Price</a>
		<a href="view_name.php">Name</a>
		<a href="view_products.php">All</a>
		<a href="view_date.php">Date</a>
		<a href="view_category.php">Category</a>	
	</div>
</div>