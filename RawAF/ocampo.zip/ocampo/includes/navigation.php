
<nav> <a href="index.php">RawAF</a> <a href="index.php">Home</a> <a href="products.php">Products</a> <a href="cart.php">Cart</a></nav>