<?php
require( "includes/database.php" );
?>


<!doctype html>
<html><head>
<meta charset="UTF-8">
<title><?php echo $title; ?></title>
<link rel="stylesheet" href="<?php echo $stylesheet; ?>">
</head>


<body>
<?php
require( "includes/navigation.php" );
?>
