<footer>
  <div class="footerlinks">
    <h4><a href="">Contact Us</a></h4>
  </div>
  <div class="footerlinks"><a href="#">Facebook</a> <a href="#">Instagram</a> <a href="#">Twitter</a></div>
  <div>
    <p>© RawAF Canada, 2018</p>
  </div>
</footer>
</body>
</html>